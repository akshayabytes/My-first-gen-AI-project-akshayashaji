// 1. Find the pieces of the page we need
const form = document.getElementById('add-form');
const nameInput = document.getElementById('food-name');
const dateInput = document.getElementById('food-date');
const photoInput = document.getElementById('food-photo');
const grid = document.getElementById('food-grid');
const emptyMessage = document.getElementById('empty-message');
const toolbar = document.getElementById('toolbar');
const searchInput = document.getElementById('search');
const summary = document.getElementById('summary');
const noResults = document.getElementById('no-results');
const filterButtons = document.querySelectorAll('.filter');
let searchText = '';
let activeFilter = 'all';

// 2. Load saved foods from the browser's notebook (or start with an empty list)
let foods = JSON.parse(localStorage.getItem('foods')) || [];

function save() {
  try {
    localStorage.setItem('foods', JSON.stringify(foods));
  } catch (error) {
    alert('Your browser storage is full. Please remove a food or a photo and try again.');
  }
}

// 3. Shrink a chosen photo so it takes up little space
function resizePhoto(file) {
  return new Promise(resolve => {
    if (!file) { resolve(''); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSize = 400;
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.onerror = () => resolve('');
      img.src = reader.result;
    };
    reader.onerror = () => resolve('');
    reader.readAsDataURL(file);
  });
}

// 4. Work out how many days are left until a date
function daysLeft(dateString) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(dateString + 'T00:00:00');
  return Math.round((expiry - today) / 86400000);
}

// 5. Turn the number of days into friendly words
function describe(days) {
  if (days < 0) return 'Expired';
  if (days === 0) return 'Expires today';
  if (days === 1) return '1 day left';
  return days + ' days left';
}

// 6. Draw the food cards that match the search and filter
function statusOf(days) {
  return days <= 2 ? 'urgent' : days <= 5 ? 'soon' : 'fresh';
}

function render() {
  grid.innerHTML = '';
  const sorted = [...foods].sort((a, b) => a.date.localeCompare(b.date));
  const needAttention = sorted.filter(food => daysLeft(food.date) <= 2).length;

  const visible = sorted.filter(food => {
    const matchesSearch = food.name.toLowerCase().includes(searchText);
    const matchesFilter = activeFilter === 'all' || statusOf(daysLeft(food.date)) === activeFilter;
    return matchesSearch && matchesFilter;
  });

  emptyMessage.hidden = foods.length > 0;
  toolbar.hidden = foods.length === 0;
  summary.hidden = foods.length === 0;
  noResults.hidden = !(foods.length > 0 && visible.length === 0);

  if (needAttention === 0) {
    summary.textContent = 'Everything is fresh. Great job!';
  } else {
    summary.textContent = needAttention + (needAttention === 1 ? ' food needs' : ' foods need') + ' attention soon.';
  }

  visible.forEach(food => {
    const days = daysLeft(food.date);

    const card = document.createElement('article');
    card.className = 'food-card ' + statusOf(days);

    if (food.photo) {
      const photo = document.createElement('img');
      photo.className = 'food-photo';
      photo.src = food.photo;
      photo.alt = food.name;
      card.append(photo);
    }

    const title = document.createElement('h3');
    title.textContent = food.name;

    const label = document.createElement('p');
    label.className = 'days';
    label.textContent = describe(days);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove';
    remove.textContent = 'Remove';
    remove.addEventListener('click', () => {
      foods = foods.filter(f => f.id !== food.id);
      save();
      render();
    });

    card.append(title, label, remove);
    grid.append(card);
  });
}

// 7. When the form is submitted, add the food
form.addEventListener('submit', async event => {
  event.preventDefault();
  const photo = await resizePhoto(photoInput.files[0]);
  foods.push({ id: Date.now(), name: nameInput.value.trim(), date: dateInput.value, photo: photo });
  save();
  render();
  form.reset();
  nameInput.focus();
});

// 8. Draw the cards once when the page first opens
render();

// 9. Fade in sections as you scroll down to them
const revealItems = document.querySelectorAll('.how h2, .cards, .tracker h2, .add-form');

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

revealItems.forEach(item => {
  item.classList.add('reveal');
  observer.observe(item);
});

// 10. Mobile menu button
const menuButton = document.getElementById('menu-button');
const menu = document.getElementById('menu');

function setMenu(open) {
  menu.classList.toggle('open', open);
  menuButton.setAttribute('aria-expanded', open);
  menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
}

menuButton.addEventListener('click', () => {
  setMenu(!menu.classList.contains('open'));
});

menu.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => setMenu(false));
});

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') setMenu(false);
});

// 11. Search box and filter buttons
searchInput.addEventListener('input', () => {
  searchText = searchInput.value.trim().toLowerCase();
  render();
});

filterButtons.forEach(button => {
  button.addEventListener('click', () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach(other => {
      const isOn = other === button;
      other.classList.toggle('active', isOn);
      other.setAttribute('aria-pressed', isOn);
    });
    render();
  });
});// 12. Quick expiry date buttons
document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    const date = new Date();
    date.setDate(date.getDate() + Number(chip.dataset.days));
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    dateInput.value = year + '-' + month + '-' + day;
  });
});// 12. Quick expiry date buttons
document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    const date = new Date();
    date.setDate(date.getDate() + Number(chip.dataset.days));
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    dateInput.value = year + '-' + month + '-' + day;
  });
});// 13. Suggest an expiry date from the type of food
const categorySelect = document.getElementById('food-category');

categorySelect.addEventListener('change', () => {
  if (!categorySelect.value) return;
  const date = new Date();
  date.setDate(date.getDate() + Number(categorySelect.value));
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  dateInput.value = year + '-' + month + '-' + day;
});  const category = categorySelect.value ? categorySelect.options[categorySelect.selectedIndex].text : '';
  foods.push({ id: Date.now(), name: nameInput.value.trim(), date: dateInput.value, photo: photo, category: category });    if (food.category) {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = food.category;
      card.append(tag);
    }